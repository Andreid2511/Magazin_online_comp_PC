<?php
    require 'db.php';
    
    echo "Conexiune reușită la baza de date: " . htmlspecialchars($db);
?>