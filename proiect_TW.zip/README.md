# Magazin online componente pc

## Structura site

* pagina home (contine o banda(ribbon) cu categoriile de produs)
* login
* profil user
* pagina produse(template filtrat, pe categorie/ cuvant cautat)
* prezentare produs(template_pt_produs)
* pagina cosul_meu
* pagina contact
* pagina faq
* pagina wishlist
* about
